import "server-only";

import { getSupabaseAdmin } from "../supabase-admin";
import { filterPublicTopics } from "../admin/cms-test-data";
import { logError } from "../logging";
import { formatArabicContentDate } from "../content-dates";
import type {
  FeedModuleConfig,
  FeedModulePayload,
  FeedModuleTemplateRow,
  TopicsFeedType,
} from "./types";

const DEFAULT_IMAGE = "/images/venesia-5.png";

function getCategoryFilterHref(slug: string) {
  return `/topics?category=${slug}`;
}

function getSeriesFilterHref(slug: string) {
  return `/topics?series=${slug}`;
}

async function loadPublishedTopicsForFilters(config: FeedModuleConfig) {
  let query = getSupabaseAdmin()
    .from("topics")
    .select("slug, title, excerpt, image, date_label, published_at, is_popular, series_slug, category_slug")
    .eq("status", "published")
    .is("deleted_at", null);

  if (config.query.categorySlug) {
    query = query.eq("category_slug", config.query.categorySlug);
  }

  if (config.query.seriesSlug) {
    query = query.eq("series_slug", config.query.seriesSlug);
  }

  const { data, error } = await query;

  if (error) {
    logError("resolveTopicsFeed: topics query failed", error, {
      categorySlug: config.query.categorySlug,
      seriesSlug: config.query.seriesSlug,
    });
    return [];
  }

  return filterPublicTopics(data ?? []);
}

async function resolveLatestOrPopular(
  feedType: Extract<TopicsFeedType, "latest" | "popular">,
  config: FeedModuleConfig,
): Promise<FeedModulePayload> {
  let query = getSupabaseAdmin()
    .from("topics")
    .select("slug, title, excerpt, image, date_label, published_at")
    .eq("status", "published")
    .is("deleted_at", null);

  if (config.query.categorySlug) {
    query = query.eq("category_slug", config.query.categorySlug);
  }

  if (config.query.seriesSlug) {
    query = query.eq("series_slug", config.query.seriesSlug);
  }

  if (feedType === "popular") {
    query = query.eq("is_popular", true);
  }

  const { data, error } = await query
    .order("published_at", { ascending: false })
    .limit(config.query.limit + 5);

  if (error) {
    logError(`resolveTopicsFeed: ${feedType} query failed`, error, {
      categorySlug: config.query.categorySlug,
      seriesSlug: config.query.seriesSlug,
    });
    return { kind: "articles", items: [] };
  }

  return {
    kind: "articles",
    items: filterPublicTopics(data ?? [])
      .slice(0, config.query.limit)
      .map((row) => ({
        title: row.title ?? "",
        excerpt: row.excerpt ?? "",
        date: row.date_label || formatArabicContentDate(row.published_at) || "",
        image: row.image || DEFAULT_IMAGE,
        href: `/topics/${row.slug}`,
      })),
  };
}

async function resolveCategories(config: FeedModuleConfig): Promise<FeedModulePayload> {
  const { data: categories, error: categoriesError } = await getSupabaseAdmin()
    .from("topic_categories")
    .select("id, name, slug, is_active, topics_count:topics(count)")
    .eq("is_active", true)
    .order("sort_order", { ascending: true })
    .order("name", { ascending: true })
    .limit(config.query.limit);

  if (categoriesError) {
    logError("resolveTopicsFeed: categories query failed", categoriesError);
    return { kind: "categories", items: [] };
  }

  let rows = categories ?? [];

  if (config.query.categorySlug) {
    rows = rows.filter((row) => row.slug === config.query.categorySlug);
  }

  if (config.query.seriesSlug) {
    const { data: seriesRow, error: seriesError } = await getSupabaseAdmin()
      .from("topic_series")
      .select("category_id")
      .eq("slug", config.query.seriesSlug)
      .maybeSingle();

    if (seriesError) {
      logError("resolveTopicsFeed: series lookup for categories failed", seriesError);
      return { kind: "categories", items: [] };
    }

    if (seriesRow?.category_id) {
      rows = rows.filter((row) => row.id === seriesRow.category_id);
    } else {
      rows = [];
    }
  }

  return {
    kind: "categories",
    items: rows.map((row) => {
      const countValue = Array.isArray(row.topics_count) ? (row.topics_count[0]?.count ?? 0) : 0;

      return {
        name: row.name,
        href: getCategoryFilterHref(row.slug),
        count: countValue,
      };
    }),
  };
}

async function loadTopicImagesBySeriesSlug(seriesSlugs: string[]) {
  if (!seriesSlugs.length) return [];

  const { data, error } = await getSupabaseAdmin()
    .from("topics")
    .select("series_slug, image, slug")
    .eq("status", "published")
    .is("deleted_at", null)
    .in("series_slug", seriesSlugs);

  if (error) {
    logError("resolveTopicsFeed: series image lookup failed", error);
    return [];
  }

  return filterPublicTopics(data ?? []);
}

async function resolveSeries(config: FeedModuleConfig): Promise<FeedModulePayload> {
  let query = getSupabaseAdmin()
    .from("topic_series")
    .select("id, name, slug, status, sort_order, category_id")
    .eq("status", "published")
    .order("sort_order", { ascending: true })
    .order("name", { ascending: true });

  if (config.query.categorySlug) {
    const { data: category, error: categoryError } = await getSupabaseAdmin()
      .from("topic_categories")
      .select("id")
      .eq("slug", config.query.categorySlug)
      .eq("is_active", true)
      .maybeSingle();

    if (categoryError) {
      logError("resolveTopicsFeed: category lookup for series failed", categoryError);
      return { kind: "series", items: [] };
    }

    if (!category?.id) return { kind: "series", items: [] };

    query = query.eq("category_id", category.id);
  }

  if (config.query.seriesSlug) {
    query = query.eq("slug", config.query.seriesSlug);
  }

  const { data: seriesRows, error: seriesError } = await query.limit(config.query.limit);

  if (seriesError) {
    logError("resolveTopicsFeed: series query failed", seriesError);
    return { kind: "series", items: [] };
  }

  const rows = seriesRows ?? [];
  const topicImages = await loadTopicImagesBySeriesSlug(rows.map((row) => row.slug));

  return {
    kind: "series",
    items: rows.map((row) => {
      const firstInSeries = topicImages.find((topic) => topic.series_slug === row.slug);

      return {
        title: row.name,
        subtitle: "",
        image: firstInSeries?.image || DEFAULT_IMAGE,
        href: getSeriesFilterHref(row.slug),
        slug: row.slug,
      };
    }),
  };
}

export async function resolveTopicsFeedModule(
  template: Pick<FeedModuleTemplateRow, "feed_type">,
  config: FeedModuleConfig,
): Promise<FeedModulePayload> {
  switch (template.feed_type) {
    case "latest":
      return resolveLatestOrPopular("latest", config);
    case "popular":
      return resolveLatestOrPopular("popular", config);
    case "categories":
      return resolveCategories(config);
    case "series":
      return resolveSeries(config);
    default:
      return { kind: "articles", items: [] };
  }
}
