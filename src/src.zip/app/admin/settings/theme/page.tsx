import AdminPlaceholderPage from "../../../../components/admin/AdminPlaceholderPage";

export default function Page() {
  return <AdminPlaceholderPage title="الثيم" />;
}
